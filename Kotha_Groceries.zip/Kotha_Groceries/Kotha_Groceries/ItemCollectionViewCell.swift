//
//  ItemCollectionViewCell.swift
//  Kotha_Groceries
//
//  Created by Sravani Kotha on 12/6/24.
//

import UIKit

class ItemCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imageView: UIImageView!
    
    
}
