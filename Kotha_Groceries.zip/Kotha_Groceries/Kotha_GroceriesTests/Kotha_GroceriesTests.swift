//
//  Kotha_GroceriesTests.swift
//  Kotha_GroceriesTests
//
//  Created by Sravani Kotha on 12/6/24.
//

import Testing
@testable import Kotha_Groceries

struct Kotha_GroceriesTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
