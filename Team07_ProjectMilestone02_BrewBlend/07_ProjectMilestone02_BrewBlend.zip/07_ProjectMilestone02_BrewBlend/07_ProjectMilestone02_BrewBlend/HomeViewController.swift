//
//  HomeViewController.swift
//  07_ProjectMilestone02_BrewBlend
//
//  Created by Srikanth Pamulapati on 11/18/24.
//

import UIKit

class HomeViewController: UIViewController {

    @IBOutlet weak var welcomeMessageOL: UILabel!
    @IBOutlet weak var fullNameOL: UILabel!
    @IBOutlet weak var searchProductOL: UITextField!
    @IBOutlet weak var searchButtonOL: UIButton!
    
    @IBOutlet weak var homeButtonOL: UIButton!
    @IBOutlet weak var cartButtonOL: UIButton!
    @IBOutlet weak var profileButtonOL: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func SearchFieldChanged(_ sender: Any) {
    }
    
    @IBAction func SearchButtonClicked(_ sender: UIButton) {
    }
    
    @IBAction func HomeBUttonClicked(_ sender: UIButton) {
    }
    
    @IBAction func CartButtonClicked(_ sender: UIButton) {
    }
    
    @IBAction func ProfileButtonClicked(_ sender: UIButton) {
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
