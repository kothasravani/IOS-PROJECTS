//
//  ProfileViewController.swift
//  07_ProjectMilestone02_BrewBlend
//
//  Created by Srikanth Pamulapati on 11/19/24.
//

import UIKit

class ProfileViewController: UIViewController {

    @IBOutlet weak var profileImageOL: UIImageView!
    @IBOutlet weak var fullNameOL: UILabel!
    @IBOutlet weak var userIDOL: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func logOutButtonClicked(_ sender: UIButton) {
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
