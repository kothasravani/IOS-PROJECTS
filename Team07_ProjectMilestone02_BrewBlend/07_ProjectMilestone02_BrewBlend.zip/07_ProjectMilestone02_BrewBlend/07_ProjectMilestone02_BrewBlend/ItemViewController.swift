//
//  ItemViewController.swift
//  07_ProjectMilestone02_BrewBlend
//
//  Created by Srikanth Pamulapati on 11/18/24.
//

import UIKit

class ItemViewController: UIViewController {

    @IBOutlet weak var itemImageOL: UIImageView!
    @IBOutlet weak var itemNameOL: UILabel!
    @IBOutlet weak var itemTagLineOL: UILabel!
    @IBOutlet weak var itemDescriptionOL: UILabel!
    @IBOutlet weak var itemRatingOL: UIButton!
    
    @IBOutlet weak var hunderedGMOL: UIButton!
    @IBOutlet weak var quarterGMOL: UIButton!
    @IBOutlet weak var halfGMOL: UIButton!
    @IBOutlet weak var oneKGOL: UIButton!
    
    @IBOutlet weak var itemFullPriceOL: UILabel!
    @IBOutlet weak var addToCartButtonOL: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func AddToCartButtonClicked(_ sender: UIButton) {
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
