//
//  Kotha_Exam03Tests.swift
//  Kotha_Exam03Tests
//
//  Created by Sravani Kotha on 12/3/24.
//

import Testing
@testable import Kotha_Exam03

struct Kotha_Exam03Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
